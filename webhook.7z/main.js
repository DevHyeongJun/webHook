
const WebHook = require('./js/webHook.js');


WebHook.send('안녕');
